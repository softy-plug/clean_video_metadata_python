# clean_video_metadata_1_0
clean_video_metadata_1_0 - utility for cleaning video metadata using ffmpeg console
